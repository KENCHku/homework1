public class Main {
    public static void main(String[] args) {


        String whyHeWasLate = "108";

        int num = 8;

        String word = whyHeWasLate + num;

        System.out.println(" dog" + 101);


        int temperature = 26;

        if (num < 0) {
            System.out.println("вы сохранили отрицательное число");
        }else if (num > 0) {
            System.out.println("вы сохранили положительное число");

        } else {
            System.out.println("вы сохранили нуль");
        }

        System.out.println(word + " " + whyHeWasLate + " " + num);


        num = 9;

        System.out.println(num);


        System.out.println("hello Kench");


    }

}







